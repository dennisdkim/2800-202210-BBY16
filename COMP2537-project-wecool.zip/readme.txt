Team Members:
[Andy Tran], [A0166629], [2D], [May 20]
[Buck Sin], [A00805677], [1B], [May 20]
[Doohyung Kim], [A01268522], [2C], [May 20]
[Lester Shun], [A01312027], [1B], [May 20]
This assignment (Milestone 3) is [100]% complete. 
Along with the bonus objectives of editing/deleting timeline posts. 

The code and functionality for the timeline feature can primarily found in:
- timeline.html
- timeline.js
- wecool-server.js (Lines 581-824)
