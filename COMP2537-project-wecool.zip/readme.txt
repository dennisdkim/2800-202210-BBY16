"# COMP2800BBY16" 
Team Members:
[Andy Tran], [A0166629], [D], [May 06]
[Buck Sin], [A00805677], [B], [May 06]
[Doohyung Kim], [A01268522], [C], [May 06]
[Lester Shun], [A01312027], [B], [May 06]
This assignment (Milestone 2) is [100]% complete.
